using System.Diagnostics;
using System.Reflection;

namespace GeoLocations.Test
{
    [TestClass]
    public class AddGeoJson
    {
        [TestMethod]
        public void AddGeoLocations()
        {
            //string geoJsonFileName = AssemblyConfigurationAttribute. //JsonFilePathGeoLocations();

            //InsertJsonToSql(geoJsonFileName,  )
            Debug.WriteLine("Here");
        }
    }
}