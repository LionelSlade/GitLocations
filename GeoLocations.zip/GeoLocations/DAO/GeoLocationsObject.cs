﻿namespace GeoLocations.DAO
{

    public class GeoLocation
    {
        public string GEO_ID { get; set; }
        public string STATE { get; set; }
        public string COUNTY { get; set; }
        public string NAME { get; set; }
        public string LSAD { get; set; }
        public string CENSUSAREA { get; set; }

        public string coordinates { get; set; }
    }
}
