﻿//https://github.com/mledoze/countries 
namespace GeoLocations.DAO
{
    internal class countriesExp
    {
        string Name;
        //List<string>
        //- common
        //-offical
        //-native
        string tld; // top level domain
        string cca2;
        string ccn3;
        string cca3;
        string cioc;
        string independent;




    }
}
