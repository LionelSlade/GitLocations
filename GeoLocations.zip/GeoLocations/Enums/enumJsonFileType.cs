﻿namespace GeoLocations.Enums
{
    public enum enumJsonFileType: ushort
    {
        Undefined = 0,
        GeoLocations = 1,
        CountryOutline = 2,
        Flags = 3,
        Capitals = 4,
        Population = 5,
        ConnectionSTR = 6,
        CountryNames = 7,

    }
}
