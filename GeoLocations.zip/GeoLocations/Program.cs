﻿using GeoLocations.DAO;
using GeoLocations.Enums;
using GeoLocations.Services;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace GeoLocations
{
    public class Program
    {       
        
        static void Main(string[] args)
        {
            //InsertJsonToSql()
            
            Console.WriteLine("Executing - ");
            var configuaration = new Configuration().Configurations;

            var ijTS = new InsertJsonToSql();
            ijTS.Execute(configuaration["JsonFilePathGeoLocations"], enumJsonFileType.GeoLocations);


            Console.WriteLine("Completed Database Build");


        }

    }

    
}
