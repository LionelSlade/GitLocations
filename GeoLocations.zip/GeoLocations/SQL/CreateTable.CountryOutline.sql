﻿CREATE TABLE [dbo].[CountryOutline](	
[ADMIN] [varchar](150) NULL,	
[ISO_A3] [varchar](3) NULL,	
[coordinates] [text] NULL) ON [PRIMARY]